/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplicacion;

import modelos.AprendizajeAutomatico;
import weka.classifiers.Classifier;
import weka.core.Instances;

/**
 *
 * @author mariano
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Leyendo textos...");
        Instances instancias = AprendizajeAutomatico.leerTexto("textos/txt_sentoken");
        System.out.println(instancias);
        System.out.println("Convirtiendo a vector...");
        instancias = AprendizajeAutomatico.convertirAVectorDePalabras(instancias);
        System.out.println(instancias);
        System.out.println("Aprendiendo modelo...");
        Classifier cls = AprendizajeAutomatico.aprenderDeInstancias(instancias);
        System.out.println(cls);
        System.out.println("Evaluando modelo...");
        System.out.println(AprendizajeAutomatico.evaluarModelo(cls, instancias).toSummaryString());
    }
    
}
