/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.TextDirectoryLoader;
import weka.core.tokenizers.NGramTokenizer;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;

/**
 *
 * @author mariano
 */
public class AprendizajeAutomatico {

    public static Instances leerTexto(String ruta) {
        TextDirectoryLoader cargador = new TextDirectoryLoader();
        try {
            cargador.setDirectory(new File(ruta));
            return cargador.getDataSet();
        } catch (IOException ex) {
            Logger.getLogger(AprendizajeAutomatico.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public static Instances convertirAVectorDePalabras(Instances instancias) {
        StringToWordVector wv = new StringToWordVector();
        NGramTokenizer nGramTokenizer = new NGramTokenizer();
        try {
            wv.setInputFormat(instancias);
            wv.setTokenizer(nGramTokenizer);
            wv.setStopwordsHandler(new MyStopWordHandler());
            return Filter.useFilter(instancias, wv);
        } catch (Exception ex) {
            Logger.getLogger(AprendizajeAutomatico.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public static Classifier aprenderDeInstancias(Instances instancias) {
        // create J48
        Classifier cls = new J48();

        try {
            // train
            cls.buildClassifier(instancias);
        } catch (Exception ex) {
            Logger.getLogger(AprendizajeAutomatico.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cls;
    }
    
    public static Evaluation evaluarModelo(Classifier cls, Instances instancias)
    {
        try {
            Evaluation evaluacion = new Evaluation(instancias);
            evaluacion.crossValidateModel(cls, instancias, 10, new Random());
            evaluacion.evaluateModel(cls, instancias);
            return evaluacion;
        } catch (Exception ex) {
            Logger.getLogger(AprendizajeAutomatico.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
