/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import weka.core.stopwords.StopwordsHandler;

/**
 *
 * @author mariano
 */
public class MyStopWordHandler implements StopwordsHandler {

    HashSet<String> stw = new HashSet<>();
    
    public MyStopWordHandler()
    {
        File ficheroStopwords = new File("stopwords.txt");
        try {
            Scanner sc = new Scanner(ficheroStopwords);
            while(sc.hasNext())
            {
                stw.add(sc.next());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MyStopWordHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public boolean isStopword(String termino) {
        return stw.contains(termino);
    }
    
}
