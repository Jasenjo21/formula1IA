/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import modelos.Modelo;

/**
 *
 * @author mariano
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Modelo modelo = new Modelo();
        modelo.aprenderModelo();
        if("{1-3}".equals(modelo.aplicarModelo())){
            System.out.println("El piloto acabará entre los 3 primeros.");
        }else{
            System.out.println("El piloto no obtendrá posición de podio.");
        }
    }

}
